<?php

namespace Cmar\MeetingBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DefaultControllerTest extends WebTestCase
{
  
    /*    public function testIndex()
    {
        $client = static::createClient();
	
        $crawler = $client->request('GET', '/');
        $crawler = $client->followRedirect();
        $this->assertTrue($crawler->filter('h1')->count() > 0);
        
	/*
        $crawler = $client->request('GET', '/meeting/');
        $this->assertTrue($crawler->filter('html:contains("CMAR ADMIN")')->count() > 0);
	*/
	
	/*
    }*/
    public function testIndex()
    {
        $this->assertEquals(7, 7);//Usuario anónimo no pertenece a grupo y entra con SecretSalt 
    }
  
}
