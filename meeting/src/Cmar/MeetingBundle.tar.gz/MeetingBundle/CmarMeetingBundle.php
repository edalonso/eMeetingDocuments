<?php

namespace Cmar\MeetingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CmarMeetingBundle extends Bundle
{
}
